# 技术字段与附件对应

本版技术字段以 `01_online-application-fields.md` 为填写入口，以 `6363d5b` 源码及 `generated/source-selection-manifest.json` 为统计依据。不要继续引用旧稿的测试通过数量或早期版本源码行数。

| 对象 | 当前口径 | 证据 |
| --- | --- | --- |
| 登记名称及版本 | 三千上课 V1.0，沿用原材料 | 所有新鉴别材料页眉 |
| 产品版本 | 1.0.0+1 | pubspec.yaml；iOS 工程 MARKETING_VERSION |
| Android/iOS 标识 | local.sanqian.schedule | android/app/build.gradle；ios/Runner.xcodeproj/project.pbxproj |
| 编程语言 | Dart、Swift、Kotlin、Java，含嵌入式 JavaScript | 本次 134 个已跟踪业务源文件；网页脚本按所在原生文件计行，不重复统计 |
| 源程序量 | 总计 29317 物理行；非空 27077 行，含注释 | 固定提交逐文件统计；不包含第三方依赖、测试和生成文件 |
| 已选鉴别材料 | 前后各 1500 非空行，合计 3000 行 | 60 页 PDF 及逐页原文件行号映射 |
| 识别服务 | 用户配置 Key，确认后调用 DeepSeek；图片复核可结合本机 OCR | PhotoScheduleImportView、ImportReviewView 及原生识别客户端 |
| 课程一致性 | 候选字段保留、差异核对、事务保存、旧记录缺失字段恢复 | ScheduleImportDraft、ScheduleImportService、SavedCourseFacts |
| 当前支持学校 | 中国艺术研究院 | SchoolAccountView 的可见支持说明 |
| 平台扩展 | 系统日历、提醒、小组件；iOS 锁屏及实时活动受系统限制 | 相关平台代码及 WidgetSettingsView |

## 上传对象与内部对象

1. 程序鉴别材料：新版 `source-identification-material.pdf`。
2. 文档鉴别材料：新版 `documentation-identification-material.pdf`。
3. 申请确认签章页：在线填写后由官网生成，申请人签字或盖章再扫描，不能由本包生成替代品。
4. 身份证明和实际适用的合同、许可证明：按主体及权利关系准备。
5. Markdown、脚本、JSON 清单、验证报告、更新记录：供内部审阅与复现，不作为默认上传附件。

本次实际核验包括固定源码提取、PDF 页数、正文行数、页面边界、名称版本一致性、文本和敏感模式检查。未重新执行 Flutter、Android 或 iOS 运行测试；本次不引用旧测试结果证明当前 App 完成。
