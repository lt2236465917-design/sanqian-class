# 三千上课软件著作权登记材料

更新日期：2026-10-14（Asia/Shanghai）。本版按已提交源码 `6363d5b2adbf62ff2a650e23be5b89d8eb4fd9d3` 更新，登记名称沿用“三千上课”，登记版本沿用 `V1.0`，对应产品 `1.0.0+1`。未向登记系统上传或提交。

## 本次可审阅材料

| 材料 | 当前文件 | 内容 |
| --- | --- | --- |
| 在线申请填写底稿 | `01_online-application-fields.md` | 可复制的开发目的、功能、技术特点、修改说明；身份及法律事实单独待确认 |
| 源程序鉴别材料 | `generated/source-identification-material.pdf` | 60 页，每页 50 条非空源程序行，取声明范围源程序的前后各 30 页 |
| 文档鉴别材料 | `generated/documentation-identification-material.pdf` | 完整 8 页设计与使用说明书，每页 37 至 38 行正文 |
| 可编辑说明书 | `content/software-manual.md` | 11 个章节，涵盖操作、设计、数据与异常处理，不再循环重复功能条目 |
| 程序取样与校验 | `generated/source-selection-manifest.json`、`generated/validation-report.json` | 固定提交、文件哈希、统计口径、每页源行映射、PDF 核验结果 |
| 权利链准备说明 | `06_rights-chain.md`、`06_rights-chain/UPSTREAM-LICENSE.txt` | 上游许可证、修改说明和需核实的证明材料 |
| 官网要求与变更 | `08_update-and-official-check.md` | 本次实读官网要求、四个新增提交和证据边界 |

同名 HTML 是便于查看的可编辑打印副本；已核验 PDF 是本次审阅基准。仓库中的旧 `generated/*.browser.pdf` 为 2026-10-11 的历史文件，保留但未收入本次更新包，勿与新版混用。

## 已按源码更新

新增学校凭据自动保存及密码遮罩、API Key 脱敏预览、独立显示外观设置、日周月导航优化、网页 AI 二次复核差异、教师/教室/教学班/编码/节次信息保留，以及 Android 长网页课表结果交接。学校账号导入只写当前支持的中国艺术研究院；Android/iOS 作为本次材料范围，未把 OpenHarmony 目录存在写成已支持平台。

本次没有更改 App 源码或产品版本，也没有重新运行 App 功能测试。说明书事实依据为该提交的代码与配置；PDF 排版检查不等于真实设备验收或登记通过。

## 官网要求与待确认事项

2026-10-14 已在 Chrome 实读官网“所需文件”“填表说明”“问题问答”。申请需要申请表、程序和文档鉴别材料、相关身份证明，以及实际适用的权利归属或许可证明。一般交存为前后各 30 页，不足 60 页交全文；通常程序每页不少于 50 行、文档每页不少于 30 行。8 页说明书按完整文档全文提供。

用户完成验证码后，已确认登录成功并核对 R11 首步表单：权利取得方式、软件全称、简称、版本号、权利范围。账号当前 R11“全部”列表显示“暂无数据”，未找到可续改的在线草稿。页面默认选中“原始取得、全部权利”，不代表申请人已作该声明。后续步骤不能直接预览，实名状态、后续字段长度与附件格式/大小限制尚未核实。

提交前仍需申请人确认：著作权人及主体信息、最终软件全称、开发完成日期、首次发表事实、开发方式、权利取得及范围、是否已有登记号。当前代码有 Apache-2.0 上游来源，许可证明应按实际权利关系和登记要求核实。签章页必须使用官网生成页面，不以本地文件替代。

## 重生成

使用已安装 `reportlab` 和 `pypdf` 的 Python 环境：

```bash
python3 copyright-materials/scripts/generate_materials.py --commit 6363d5b2adbf62ff2a650e23be5b89d8eb4fd9d3 --version V1.0
python3 copyright-materials/scripts/verify_printed_pdfs.py
python3 copyright-materials/scripts/check_sensitive.py
git diff --check -- copyright-materials
```

生成器读取固定 Git 提交，不混入工作区未提交 App 修改；默认字体路径适用于当前 macOS 环境。重新生成后应重新查看 PDF。清单、报告、脚本和本说明是内部准备材料，通常不作为程序或文档鉴别材料上传。
