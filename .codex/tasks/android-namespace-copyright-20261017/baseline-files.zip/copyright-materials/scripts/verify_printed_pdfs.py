#!/usr/bin/env python3
"""Verify actual generated PDFs against the fixed source selection and manuscript."""
from pathlib import Path
import hashlib
import json
import re
from pypdf import PdfReader
import generate_materials as gen

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'copyright-materials/generated'


def canonical(text):
    return re.sub(r'\s+', '', text)


def check_pdf(filename, expected_pages, title, expected_rows, source=False):
    path=OUT/filename
    reader=PdfReader(path)
    assert len(reader.pages)==expected_pages
    results=[]
    for n, page in enumerate(reader.pages,1):
        text=page.extract_text()
        assert '三千上课 V1.0' in text
        assert f'第 {n} 页 / 共 {expected_pages} 页' in text
        assert title in text
        assert abs(float(page.mediabox.width)-gen.WIDTH)<1
        assert abs(float(page.mediabox.height)-gen.HEIGHT)<1
        body=[]; left_numbers=[]; bounds=[]
        def visit(txt,cm,tm,font,size):
            if not txt.strip(): return
            x,y=float(tm[4]),float(tm[5])
            if 45 < y < 790:
                if source and x < gen.LEFT+28:
                    left_numbers.append(txt.strip())
                else:
                    body.append(txt)
                bounds.append((x,y))
        page.extract_text(visitor_text=visit)
        rows=expected_rows[n-1]
        expected=''.join(row['text'].expandtabs(4) for row in rows)
        actual=''.join(body)
        assert canonical(expected)==canonical(actual), ('body text mismatch',filename,n)
        if source:
            assert left_numbers==[str(row['streamLine']) for row in rows],('line numbers',n)
            assert len(left_numbers)==50
        hits=[name for name,pattern in gen.SENSITIVE_PATTERNS.items() if pattern.search(text)]
        assert not hits,(filename,n,hits)
        assert all(39<=x<=gen.RIGHT and 45<y<790 for x,y in bounds)
        results.append({'page':n,'sourceLines':len(rows) if source else None,'bodyLines':len(rows) if not source else None,'exactTextMatchIgnoringLayoutWhitespace':True,'headerFooterAndPageNumber':True})
    return {'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'pages':len(reader.pages),'pageChecks':results,'pass':True}


def main():
    report_path=OUT/'validation-report.json'
    report=json.loads(report_path.read_text())
    gen.font_setup()
    source,files,excluded,counts=gen.collect(report['sourceCommit'])
    manual=gen.manual_lines(ROOT/'copyright-materials/content/software-manual.md')
    # Verify every displayed character has a real font glyph.
    missing=set()
    for mode,pages in [(True,source),(False,manual)]:
        for page in pages:
            for row in page:
                for char in row['text'].expandtabs(4):
                    if char.isspace():continue
                    font=gen.font_for(char,mode)
                    if ord(char) not in gen.pdfmetrics.getFont(font).face.charToGlyph: missing.add(f'U+{ord(char):04X}')
    assert not missing,sorted(missing)
    checks={
       'source':check_pdf('source-identification-material.pdf',len(source),'源程序鉴别材料',source,True),
       'documentation':check_pdf('documentation-identification-material.pdf',len(manual),'软件设计与使用说明书',manual),
    }
    # This script verifies local PDF files; website observations are recorded separately.
    report.update({'pdfTextVerified':True,'pdfVerification':checks,'glyphCoveragePass':True,'localStructuralVerificationPass':True})
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:{n:v[n] for n in ('pages','bytes','sha256','pass')} for k,v in checks.items()},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
