#!/usr/bin/env python3
"""Generate local copyright materials from an immutable committed source tree."""
from __future__ import annotations
import argparse
import hashlib
import html
import json
import math
import re
import subprocess
from pathlib import Path
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'copyright-materials' / 'generated'
DEFAULT_COMMIT = '6363d5b2adbf62ff2a650e23be5b89d8eb4fd9d3'
SOFTWARE = '三千上课'
WIDTH, HEIGHT = A4
LEFT, RIGHT, TOP, BOTTOM = 40, WIDTH - 40, HEIGHT - 63, 46
EXCLUDE_PARTS = {'.git', '.dart_tool', 'build', 'test', 'tests', 'reference', 'mock', 'generated', 'Pods', '.symlinks', 'Debug'}
EXCLUDE_NAMES = {'GeneratedPluginRegistrant.java', 'GeneratedPluginRegistrant.swift', 'WidgetPreviews.swift', 'PreviewData.swift', 'ScreenshotImportView.dart', 'ScreenshotScheduleImporter.dart', 'ScreenshotSchedule.dart'}
SOURCE_SUFFIXES = {'.dart', '.swift', '.kt', '.java'}
SENSITIVE_PATTERNS = {
    'private-key': re.compile(r'BEGIN (?:RSA|OPENSSH|EC|DSA) PRIVATE KEY'),
    'api-key-shape': re.compile(r'(?i)sk-[a-z0-9]{12,}'),
    'bearer-token': re.compile(r'(?i)Bearer\s+[A-Za-z0-9._-]{16,}'),
    'secret-literal': re.compile(r'''(?i)(?:password|passwd|api[_-]?key)\s*[:=]\s*["'][A-Za-z0-9@#!%+/.=-]{8,}["']'''),
}


def git(*args: str) -> bytes:
    return subprocess.run(['git', *args], cwd=ROOT, check=True, capture_output=True).stdout


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def font_setup():
    pdfmetrics.registerFont(TTFont('CN', '/System/Library/Fonts/STHeiti Light.ttc', subfontIndex=0))
    pdfmetrics.registerFont(TTFont('Mono', '/System/Library/Fonts/Menlo.ttc', subfontIndex=0))


def font_for(char: str, mono=False) -> str:
    if mono and ord(char) < 128:
        return 'Mono'
    return 'CN'


def text_width(text: str, size: float, mono=False) -> float:
    return sum(pdfmetrics.stringWidth(c, font_for(c, mono), size) for c in text)


def wrap(text: str, size: float, width: float, mono=False) -> list[str]:
    chunks, line, used = [], '', 0.0
    tokens = list(text.expandtabs(4)) if mono else re.findall(r'[A-Za-z0-9_./+\-]+|\s+|.', text)
    for char in tokens:
        cw = text_width(char, size, mono)
        if line and used + cw > width:
            if not mono and char in '，。；：？！、）”》':
                moved = line[-1]
                line = line[:-1]
                chunks.append(line)
                line, used = moved, text_width(moved, size, mono)
            else:
                chunks.append(line)
                line, used = '', 0.0
        if not mono and not line and char.isspace() and char != '　　':
            continue
        line += char
        used += cw
    if line:
        chunks.append(line)
    return chunks or ['']


def draw_text(pdf, x, y, text, size, mono=False):
    run, current = '', None
    for char in text:
        font = font_for(char, mono)
        if font != current and run:
            pdf.setFont(current, size)
            pdf.drawString(x, y, run)
            x += pdfmetrics.stringWidth(run, current, size)
            run = ''
        current, run = font, run + char
    if run:
        pdf.setFont(current, size)
        pdf.drawString(x, y, run)


def collect(commit: str):
    paths = git('ls-tree', '-r', '--name-only', commit, '--', 'lib', 'ios', 'android').decode().splitlines()
    eligible, excluded = [], []
    for rel in paths:
        p = Path(rel)
        reason = None
        if p.suffix not in SOURCE_SUFFIXES: reason = 'not-program-source'
        elif any(part in EXCLUDE_PARTS for part in p.parts): reason = 'test-generated-dependency-debug'
        elif p.name in EXCLUDE_NAMES or p.name.endswith(('Tests.swift', 'Test.swift', '.g.dart')): reason = 'test-generated-preview-or-fixture'
        if reason:
            excluded.append({'path': rel, 'reason': reason})
        else:
            eligible.append(rel)
    def order(rel):
        return (0 if rel == 'lib/main.dart' else 1 if rel.startswith('lib/') else 2 if rel.startswith('ios/') else 3, rel)
    all_lines, files, counts = [], [], {}
    for rel in sorted(eligible, key=order):
        data = git('show', f'{commit}:{rel}')
        raw = data.decode('utf-8').splitlines()
        selected = [(n, line) for n, line in enumerate(raw, 1) if line.strip()]
        start = len(all_lines) + 1
        for n, line in selected:
            all_lines.append({'path': rel, 'sourceLine': n, 'text': line, 'streamLine': len(all_lines)+1})
        files.append({'path': rel, 'sha256': sha(data), 'physicalLines': len(raw), 'nonblankLines': len(selected), 'streamStart': start, 'streamEnd': len(all_lines)})
        lang = {'.dart': 'Dart', '.swift': 'Swift', '.kt': 'Kotlin', '.java': 'Java'}[Path(rel).suffix]
        count = counts.setdefault(lang, {'files': 0, 'physicalLines': 0, 'nonblankLines': 0})
        count['files'] += 1; count['physicalLines'] += len(raw); count['nonblankLines'] += len(selected)
    if len(all_lines) < 3000:
        source_pages = [all_lines[i:i+50] for i in range(0, len(all_lines), 50)]
    else:
        picked = all_lines[:1500] + all_lines[-1500:]
        source_pages = [picked[i:i+50] for i in range(0, 3000, 50)]
    return source_pages, files, excluded, counts


def manual_lines(path):
    lines = []
    for pid, raw in enumerate(path.read_text().splitlines()):
        if not raw.strip(): continue
        level = len(raw) - len(raw.lstrip('#')) if raw.startswith('#') else 0
        text = raw.lstrip('#').strip() if level else raw.strip()
        size = 13 if level == 1 else 11.5 if level == 2 else 10.5
        if not level and not re.match(r'^\d+ ', text):
            text = '　　' + text
        for n, line in enumerate(wrap(text, size, RIGHT-LEFT)):
            lines.append({'text': line, 'size': size, 'heading': bool(level), 'first': n == 0, 'paragraph': pid})
    # Balance the complete document into real text lines, without blank or repeated filler.
    page_count = max(1, math.ceil(len(lines) / 39))
    pages, cursor = [], 0
    for i in range(page_count):
        count = math.ceil((len(lines)-cursor)/(page_count-i))
        if cursor+count < len(lines) and lines[cursor+count-1]['heading']:
            count -= 1
        if cursor+count < len(lines) and lines[cursor+count-1]['paragraph'] == lines[cursor+count]['paragraph']:
            start = cursor+count-1
            while start > cursor and lines[start-1]['paragraph'] == lines[start]['paragraph']:
                start -= 1
            if start-cursor >= 30:
                count = start-cursor
        pages.append(lines[cursor:cursor+count]); cursor += count
    assert cursor == len(lines)
    assert page_count == 1 or min(map(len, pages)) >= 30, [len(p) for p in pages]
    return pages


def frame(pdf, version, title, num, total):
    pdf.setFillColorRGB(0, 0, 0)
    draw_text(pdf, LEFT, HEIGHT-33, f'{SOFTWARE} {version}  {title}', 9)
    marker = f'第 {num} 页 / 共 {total} 页'
    draw_text(pdf, RIGHT-text_width(marker, 9), HEIGHT-33, marker, 9)
    draw_text(pdf, LEFT, 26, f'{SOFTWARE} {version}', 8)
    draw_text(pdf, RIGHT-text_width(title, 8), 26, title, 8)


def source_layout(page):
    size = 9.0
    while True:
        rows = [wrap(row['text'], size, RIGHT-LEFT-29, True) for row in page]
        leading = size * 1.35
        if sum(map(len, rows))*leading <= TOP-BOTTOM: return size, leading, rows
        size -= 0.1
        if size < 6.9: raise ValueError('Source page requires smaller than 7pt; revise pagination explicitly')


def render_source(out, version, pages):
    title = '源程序鉴别材料'
    pdfpath = out/'source-identification-material.pdf'
    pdf = canvas.Canvas(str(pdfpath), pagesize=A4, pageCompression=1)
    pdf.setTitle(f'{SOFTWARE} {version} {title}'); pdf.setAuthor('')
    page_html, statistics = [], []
    for num, page in enumerate(pages, 1):
        frame(pdf, version, title, num, len(pages))
        size, leading, visual = source_layout(page)
        y = TOP; blocks = []
        for row, wrapped in zip(page, visual):
            pdf.setFillColorRGB(.42, .42, .42)
            draw_text(pdf, LEFT, y, str(row['streamLine']), 6.5, True)
            pdf.setFillColorRGB(0, 0, 0)
            for line in wrapped:
                draw_text(pdf, LEFT+29, y, line, size, True)
                y -= leading
            blocks.append(f"<div class='code'><span class='num'>{row['streamLine']}</span><span>{html.escape(row['text'].expandtabs(4))}</span></div>")
        statistics.append({'page': num, 'nonblankSourceLines': len(page), 'printedTextLines': sum(map(len, visual)), 'fontSize': round(size,2), 'bodyBottom': round(y+leading,2), 'streamStart': page[0]['streamLine'], 'streamEnd': page[-1]['streamLine']})
        page_html.append(section(version,title,num,len(pages),''.join(blocks),f'font-size:{size}pt;line-height:{leading}pt'))
        pdf.showPage()
    pdf.save()
    write_html(out/'source-identification-material.html',title,page_html)
    return statistics


def section(version,title,num,total,body,style=''):
    return f"<section class='page'><header><span>{SOFTWARE} {version} {title}</span><span>第 {num} 页 / 共 {total} 页</span></header><main style='{style}'>{body}</main><footer>{SOFTWARE} {version}　{title}</footer></section>"


def write_html(path,title,pages):
    path.write_text("<!doctype html><html lang='zh-CN'><meta charset='utf-8'><title>"+SOFTWARE+' '+title+"</title><style>@page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;color:#111;font-family:'Heiti SC','PingFang SC',sans-serif;background:#ddd}.page{width:210mm;height:297mm;margin:0 auto 12px;padding:11mm 14mm 14mm;position:relative;background:white;break-after:page}.page:last-child{break-after:auto}header{display:flex;justify-content:space-between;font-size:9pt}main{margin-top:7mm}footer{position:absolute;bottom:9mm;font-size:8pt}.code{display:flex;font-family:Menlo,'Heiti SC',monospace;white-space:pre-wrap;overflow-wrap:anywhere}.num{display:inline-block;flex:0 0 29pt;color:#777;font-size:6.5pt}.docline{height:18pt;line-height:18pt;white-space:pre}.heading{font-weight:600}@media print{body{background:white}.page{margin:0}}</style><body>"+''.join(pages)+'</body></html>',encoding='utf-8')


def render_manual(out, version, pages):
    title='软件设计与使用说明书'
    pdf=canvas.Canvas(str(out/'documentation-identification-material.pdf'),pagesize=A4,pageCompression=1)
    pdf.setTitle(f'{SOFTWARE} {version} {title}'); pdf.setAuthor('')
    htmlpages=[]
    for num,page in enumerate(pages,1):
        frame(pdf,version,title,num,len(pages)); y=TOP; body=[]
        for row in page:
            draw_text(pdf,LEFT,y,row['text'],row['size']); y-=18
            css='docline heading' if row['heading'] else 'docline'
            body.append(f"<div class='{css}' style='font-size:{row['size']}pt'>{html.escape(row['text'])}</div>")
        assert y+18>BOTTOM
        htmlpages.append(section(version,title,num,len(pages),''.join(body)))
        pdf.showPage()
    pdf.save(); write_html(out/'documentation-identification-material.html',title,htmlpages)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--version',default='V1.0')
    parser.add_argument('--commit',default=DEFAULT_COMMIT)
    parser.add_argument('--out',type=Path,default=OUT)
    args=parser.parse_args(); out=args.out.resolve(); out.mkdir(parents=True,exist_ok=True)
    commit=git('rev-parse',f'{args.commit}^{{commit}}').decode().strip()
    font_setup()
    source,files,excluded,counts=collect(commit)
    full_selected='\n'.join(row['text'] for page in source for row in page)
    hits=[name for name,pattern in SENSITIVE_PATTERNS.items() if pattern.search(full_selected)]
    if hits: raise ValueError(f'Source secret patterns need review: {hits}')
    manual_path=ROOT/'copyright-materials/content/software-manual.md'
    documentation=manual_lines(manual_path)
    stats=render_source(out,args.version,source)
    render_manual(out,args.version,documentation)
    manifest={'software':SOFTWARE,'versionHeader':args.version,'productVersion':'1.0.0+1','sourceCommit':commit,'sourceCommitDate':git('show','-s','--format=%cI',commit).decode().strip(),'scope':'Android and iOS client source; inherited and modified code included; not a measure of applicant-only authorship','sourceOrder':'lib/main.dart; other lib paths; ios paths; android paths; lexical within group','countingRule':'UTF-8 splitlines; comments included; blank lines removed for printable stream, no source literals replaced; line numbers are stream indices, not program code','eligiblePhysicalLines':sum(f['physicalLines'] for f in files),'eligibleNonblankLines':sum(f['nonblankLines'] for f in files),'selectedNonblankLines':sum(map(len,source)),'selectionRule':'First 1500 and last 1500 consecutive nonblank lines of declared complete source stream; 50 per page','languages':counts,'files':files,'excludedFiles':excluded,'excludedPlatforms':['ohos','web'],'redactions':[],'pageMap':[[{k:row[k] for k in ('path','sourceLine','streamLine')} for row in page] for page in source],'manualSha256':sha(manual_path.read_bytes())}
    (out/'source-selection-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    report={'sourceCommit':commit,'versionHeader':args.version,'productVersion':'1.0.0+1','source':{'pages':len(source),'minimumNonblankSourceLines':min(map(len,source)),'pagesDetail':stats},'documentation':{'pages':len(documentation),'bodyLineCounts':[len(p) for p in documentation],'completeDocument':True,'authoringMethod':'Original structured design and use manual; no cyclic repetition or filler'},'pdfGenerated':True,'pdfTextVerified':False,'visualReview':'NOT_VERIFIED','officialAcceptance':'NOT_VERIFIED','runtimeAppTest':'Not executed in this documentation-only task','sensitivePatternHits':hits}
    (out/'validation-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'commit':commit,'sourcePages':len(source),'manualPages':len(documentation),'manualLines':[len(p) for p in documentation],'eligiblePhysicalLines':manifest['eligiblePhysicalLines'],'eligibleNonblankLines':manifest['eligibleNonblankLines'],'languages':counts,'minimumSourceFont':min(p['fontSize'] for p in stats)},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
